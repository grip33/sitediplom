   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; <?php echo date('Y');?> Батыржанов Арыстан и Калей Аружан 
                </div>

            </div>
        </div>
    </section>